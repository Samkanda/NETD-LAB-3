﻿' Author: Navpreet Kanda
' Recognition: This program was created based on the example provided by Kyle Chapman. 
' Date Created: 2020-02-25
' Description:
'   Takes input of a unit value, validates it and adds it to a list

Option Strict On

Public Class frmEmployeeUnits

#Region "Variable Declarations"
    Dim day As Integer = 0
    Dim employee As Integer = 0

    Dim employeeTotalUnits As Double
    Dim overallTotalUnits As Double

    Dim unitArray(2, 6) As Integer


    Dim employeeAverageUnits As Double
    Dim overallAverageUnits As Double

    Dim textboxArray() As TextBox
    Dim outputLabelArray() As Label

#End Region

#Region "Declaring Arrays and Event Handlers"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Array of each employee textbox
        textboxArray = {txtUnitsEmployee1, txtUnitsEmployee2, txtUnitsEmployee3}
        ' Array of each Average employee label
        outputLabelArray = {lblEmployee1Output, lblEmployee2Output, lblEmployee3Output}


    End Sub

    Sub Reset()
        ' Clear the textboxes for input and output
        txtUnitInput.Clear()
        txtUnitsEmployee1.Clear()
        txtUnitsEmployee2.Clear()
        txtUnitsEmployee3.Clear()

        ' Clear all output labels
        lblEmployee1Output.Text = String.Empty
        lblEmployee2Output.Text = String.Empty
        lblEmployee3Output.Text = String.Empty
        lblAverageOutput.Text = String.Empty

        ' Re-enable input controls
        txtUnitInput.Enabled = True
        btnEnter.Enabled = True

        ' Set default values
        day = 0
        employee = 0
        lblDay.Text = "Day " & (day + 1)
        employeeTotalUnits = 0
        overallTotalUnits = 0

        ' Set focus
        txtUnitInput.Focus()
    End Sub


    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        'Variable declaration
        Const DaysInWeek As Integer = 7
        Const NumberOfEmployees As Integer = 3

        ' Checks if the value is valid
        If Integer.TryParse(txtUnitInput.Text, unitArray(employee, day)) Then

            ' Checked if the number is between the 0 - 5000
            If unitArray(employee, day) >= 0 And unitArray(employee, day) <= 5000 Then

                ' Output the new unit value
                textboxArray(employee).Text &= unitArray(employee, day) & vbCrLf

                ' If the value is valid, increase the day counter by 1
                day += 1
                lblDay.Text = "Day " & (day + 1)

                ' Clears the input box for the next value to be entered
                txtUnitInput.Clear()

                ' If the day counter is equal to 7
                If day = DaysInWeek Then

                    ' Reset the employee Total
                    employeeTotalUnits = 0

                    ' Loops through employee unit values and adds to total
                    For dayCounter As Integer = 0 To DaysInWeek - 1
                        employeeTotalUnits += unitArray(employee, dayCounter)
                    Next

                    ' Dividies total by 7 (Days in week)
                    employeeAverageUnits = employeeTotalUnits / DaysInWeek

                    ' Outputs values in label average
                    outputLabelArray(employee).Text = "Average:" & Math.Round(employeeAverageUnits, 2)

                    ' Adds one to employee to indicate storing into next box
                    employee += 1

                    ' Reset the day to 0
                    day = 0
                    lblDay.Text = "Day " & (day + 1)

                    ' If we have reached emlpoye 3, caclulate the total average of all employees
                    If employee = NumberOfEmployees Then

                        ' Add total units for the three weeks
                        For Each day In unitArray
                            overallTotalUnits += day
                        Next

                        ' Determine and output the average (overall total / number of days)
                        overallAverageUnits = overallTotalUnits / unitArray.Length
                        lblAverageOutput.Text = "Average: " & Math.Round(overallAverageUnits, 2)

                        ' Disable the input-related controls
                        txtUnitInput.Enabled = False
                        btnEnter.Enabled = False
                        btnReset.Focus()

                        lblDay.Text = "Done"

                    End If

                End If

            Else
                ' Error Message for incorrect Range
                MessageBox.Show("Unit must be within 0 - 5000")
                txtUnitInput.SelectAll()
                txtUnitInput.Focus()
            End If

        Else
            ' Error for incorrect Data Type
            MessageBox.Show("Unit must be a valid number")
            txtUnitInput.SelectAll()
            txtUnitInput.Focus()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
#End Region


End Class
