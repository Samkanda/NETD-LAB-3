﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmployeeUnits
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblEmployee1 = New System.Windows.Forms.Label()
        Me.lblEmployee2 = New System.Windows.Forms.Label()
        Me.lblEmployee3 = New System.Windows.Forms.Label()
        Me.lblEmployee1Output = New System.Windows.Forms.Label()
        Me.lblEmployee2Output = New System.Windows.Forms.Label()
        Me.lblEmployee3Output = New System.Windows.Forms.Label()
        Me.lblAverageOutput = New System.Windows.Forms.Label()
        Me.txtUnitInput = New System.Windows.Forms.TextBox()
        Me.txtUnitsEmployee1 = New System.Windows.Forms.TextBox()
        Me.txtUnitsEmployee2 = New System.Windows.Forms.TextBox()
        Me.txtUnitsEmployee3 = New System.Windows.Forms.TextBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblDay
        '
        Me.lblDay.AutoSize = True
        Me.lblDay.Location = New System.Drawing.Point(25, 26)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(35, 13)
        Me.lblDay.TabIndex = 0
        Me.lblDay.Text = "Day 1"
        Me.ToolTip.SetToolTip(Me.lblDay, "Day indicator")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Units"
        '
        'lblEmployee1
        '
        Me.lblEmployee1.AutoSize = True
        Me.lblEmployee1.Location = New System.Drawing.Point(47, 123)
        Me.lblEmployee1.Name = "lblEmployee1"
        Me.lblEmployee1.Size = New System.Drawing.Size(62, 13)
        Me.lblEmployee1.TabIndex = 2
        Me.lblEmployee1.Text = "Employee 1"
        Me.ToolTip.SetToolTip(Me.lblEmployee1, "Employee 1 label")
        '
        'lblEmployee2
        '
        Me.lblEmployee2.AutoSize = True
        Me.lblEmployee2.Location = New System.Drawing.Point(160, 123)
        Me.lblEmployee2.Name = "lblEmployee2"
        Me.lblEmployee2.Size = New System.Drawing.Size(62, 13)
        Me.lblEmployee2.TabIndex = 3
        Me.lblEmployee2.Text = "Employee 2"
        Me.ToolTip.SetToolTip(Me.lblEmployee2, "Employee 2 label")
        '
        'lblEmployee3
        '
        Me.lblEmployee3.AutoSize = True
        Me.lblEmployee3.Location = New System.Drawing.Point(269, 123)
        Me.lblEmployee3.Name = "lblEmployee3"
        Me.lblEmployee3.Size = New System.Drawing.Size(62, 13)
        Me.lblEmployee3.TabIndex = 4
        Me.lblEmployee3.Text = "Employee 3"
        Me.ToolTip.SetToolTip(Me.lblEmployee3, "Employee 3 label")
        '
        'lblEmployee1Output
        '
        Me.lblEmployee1Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee1Output.Location = New System.Drawing.Point(26, 280)
        Me.lblEmployee1Output.MaximumSize = New System.Drawing.Size(105, 19)
        Me.lblEmployee1Output.MinimumSize = New System.Drawing.Size(105, 19)
        Me.lblEmployee1Output.Name = "lblEmployee1Output"
        Me.lblEmployee1Output.Size = New System.Drawing.Size(105, 19)
        Me.lblEmployee1Output.TabIndex = 5
        Me.lblEmployee1Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip.SetToolTip(Me.lblEmployee1Output, "Average output for employee 1")
        '
        'lblEmployee2Output
        '
        Me.lblEmployee2Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee2Output.Location = New System.Drawing.Point(134, 280)
        Me.lblEmployee2Output.MaximumSize = New System.Drawing.Size(105, 19)
        Me.lblEmployee2Output.MinimumSize = New System.Drawing.Size(105, 19)
        Me.lblEmployee2Output.Name = "lblEmployee2Output"
        Me.lblEmployee2Output.Size = New System.Drawing.Size(105, 19)
        Me.lblEmployee2Output.TabIndex = 6
        Me.lblEmployee2Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip.SetToolTip(Me.lblEmployee2Output, "Average output for employee 2")
        '
        'lblEmployee3Output
        '
        Me.lblEmployee3Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee3Output.Location = New System.Drawing.Point(243, 280)
        Me.lblEmployee3Output.MaximumSize = New System.Drawing.Size(105, 19)
        Me.lblEmployee3Output.MinimumSize = New System.Drawing.Size(105, 19)
        Me.lblEmployee3Output.Name = "lblEmployee3Output"
        Me.lblEmployee3Output.Size = New System.Drawing.Size(105, 19)
        Me.lblEmployee3Output.TabIndex = 7
        Me.lblEmployee3Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip.SetToolTip(Me.lblEmployee3Output, "Average output for employee 3")
        '
        'lblAverageOutput
        '
        Me.lblAverageOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageOutput.Location = New System.Drawing.Point(25, 309)
        Me.lblAverageOutput.MaximumSize = New System.Drawing.Size(320, 19)
        Me.lblAverageOutput.MinimumSize = New System.Drawing.Size(320, 19)
        Me.lblAverageOutput.Name = "lblAverageOutput"
        Me.lblAverageOutput.Size = New System.Drawing.Size(320, 19)
        Me.lblAverageOutput.TabIndex = 8
        Me.lblAverageOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip.SetToolTip(Me.lblAverageOutput, "Total average of units for all employees")
        '
        'txtUnitInput
        '
        Me.txtUnitInput.Location = New System.Drawing.Point(70, 57)
        Me.txtUnitInput.Name = "txtUnitInput"
        Me.txtUnitInput.Size = New System.Drawing.Size(68, 20)
        Me.txtUnitInput.TabIndex = 9
        Me.ToolTip.SetToolTip(Me.txtUnitInput, "Input box for number of units")
        '
        'txtUnitsEmployee1
        '
        Me.txtUnitsEmployee1.Location = New System.Drawing.Point(28, 139)
        Me.txtUnitsEmployee1.Multiline = True
        Me.txtUnitsEmployee1.Name = "txtUnitsEmployee1"
        Me.txtUnitsEmployee1.ReadOnly = True
        Me.txtUnitsEmployee1.Size = New System.Drawing.Size(103, 123)
        Me.txtUnitsEmployee1.TabIndex = 10
        Me.ToolTip.SetToolTip(Me.txtUnitsEmployee1, "Values of units of the week for employee 1")
        '
        'txtUnitsEmployee2
        '
        Me.txtUnitsEmployee2.Location = New System.Drawing.Point(137, 139)
        Me.txtUnitsEmployee2.Multiline = True
        Me.txtUnitsEmployee2.Name = "txtUnitsEmployee2"
        Me.txtUnitsEmployee2.ReadOnly = True
        Me.txtUnitsEmployee2.Size = New System.Drawing.Size(103, 123)
        Me.txtUnitsEmployee2.TabIndex = 11
        Me.ToolTip.SetToolTip(Me.txtUnitsEmployee2, "Values of units of the week for employee 2")
        '
        'txtUnitsEmployee3
        '
        Me.txtUnitsEmployee3.Location = New System.Drawing.Point(246, 139)
        Me.txtUnitsEmployee3.Multiline = True
        Me.txtUnitsEmployee3.Name = "txtUnitsEmployee3"
        Me.txtUnitsEmployee3.ReadOnly = True
        Me.txtUnitsEmployee3.Size = New System.Drawing.Size(103, 123)
        Me.txtUnitsEmployee3.TabIndex = 12
        Me.ToolTip.SetToolTip(Me.txtUnitsEmployee3, "Values of units of the week for employee 3")
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(147, 344)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 13
        Me.btnReset.Text = "&Reset"
        Me.ToolTip.SetToolTip(Me.btnReset, "Reset button to clear boxes and labels")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(34, 344)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 14
        Me.btnEnter.Text = "&Enter"
        Me.ToolTip.SetToolTip(Me.btnEnter, "Enter button to store value of input typed")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(256, 344)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 25)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "&Exit"
        Me.ToolTip.SetToolTip(Me.btnExit, "Exit button to close program")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmEmployeeUnits
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(397, 450)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.txtUnitsEmployee3)
        Me.Controls.Add(Me.txtUnitsEmployee2)
        Me.Controls.Add(Me.txtUnitsEmployee1)
        Me.Controls.Add(Me.txtUnitInput)
        Me.Controls.Add(Me.lblAverageOutput)
        Me.Controls.Add(Me.lblEmployee3Output)
        Me.Controls.Add(Me.lblEmployee2Output)
        Me.Controls.Add(Me.lblEmployee1Output)
        Me.Controls.Add(Me.lblEmployee3)
        Me.Controls.Add(Me.lblEmployee2)
        Me.Controls.Add(Me.lblEmployee1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblDay)
        Me.Name = "frmEmployeeUnits"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Employee Units"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDay As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblEmployee1 As Label
    Friend WithEvents lblEmployee2 As Label
    Friend WithEvents lblEmployee3 As Label
    Friend WithEvents lblEmployee1Output As Label
    Friend WithEvents lblEmployee2Output As Label
    Friend WithEvents lblEmployee3Output As Label
    Friend WithEvents lblAverageOutput As Label
    Friend WithEvents txtUnitInput As TextBox
    Friend WithEvents txtUnitsEmployee1 As TextBox
    Friend WithEvents txtUnitsEmployee2 As TextBox
    Friend WithEvents txtUnitsEmployee3 As TextBox
    Friend WithEvents btnReset As Button
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ToolTip As ToolTip
End Class
